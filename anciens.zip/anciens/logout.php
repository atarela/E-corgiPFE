<?php 
require_once('C:\wamp64\www\simplesamlphp\lib\_autoload.php');
$auth = new SimpleSAML_Auth_Simple('default-sp');
$auth->logout('http://localhost/anciens/home-02.php');
SimpleSAML_Session::getSessionFromRequest()->cleanup();
?>
<html>
<head>
<title>A BASIC HTML FORM</title>
</head>
<body>
<Form name ="form1" Method ="POST" Action ="submitForm.php">
         <INPUT TYPE = "TEXT" VALUE ="username" Name ="username">
         <INPUT TYPE = "Submit" Name = "Submit1" VALUE = "Login">
</FORM>
</body>
</html>